# PokeScan

Scan a Pokémon card, see its TCGplayer market price and price history, and keep a collection with a running portfolio value. One codebase runs as a **website, an iOS app, and an Android app**.

- Minimal, flat design with light and dark themes (no gradients, no purple)
- Collection saved on your device (no account needed in v1)
- Prices and history only (no marketplace or checkout in v1)

## Status

Early scaffold. The shared logic (card matching, price parsing, collection math, chart geometry, theme rules, scan endpoint) is covered by automated tests that pass. The screens have **not yet been run on a device or browser**, so expect small fixes on first launch. See [Known gaps](#known-gaps).

## Stack

| Piece | Choice |
|---|---|
| App + web | Expo (React Native) with Expo Router, TypeScript |
| Card data and images | [TCGdex](https://tcgdex.dev) (free, no key) |
| Prices and history | [TickerMint](https://tickermint.cards) (daily TCGplayer market prices since Feb 2024) |
| Card recognition | `api/identify.ts` calls a Claude vision model from the server, so your key never ships in the app |
| Storage | AsyncStorage on the device |

> **Why not pokemontcg.io?** It is deprecated and scheduled to go offline on March 1, 2027, and new API keys are closed. Every provider lives in one small file (`src/lib/tcgdex.ts`, `src/lib/prices.ts`) so it can be swapped later.

## Quick start

You need Node.js 22 or newer.

```bash
npm install
npx expo install --fix     # aligns every package to the Expo SDK in package.json
npm run check              # typecheck + tests
npm run web                # opens the website locally
```

To run on a phone, install **Expo Go** and scan the QR code from `npx expo start`.

> **Expo Go and SDK versions.** This project targets Expo SDK 57 because the store version of Expo Go currently supports 57. SDK 58 is newer; to move up, run `npx expo install expo@^58.0.0 --fix` and use a development build (`npx expo run:ios` / `run:android`) instead of Expo Go.

If `npm install` gives dependency errors, the fallback is: create a fresh app with `npx create-expo-app@latest`, then copy `app/`, `src/`, `api/`, `tests/`, and `assets/` over it and run `npx expo install expo-camera expo-image expo-image-picker react-native-svg @react-native-async-storage/async-storage @expo/vector-icons`.

## Turning on scanning

Scanning sends a photo to `POST /api/identify`, which asks a vision model to read the card name and collector number. The app then looks the card up in TCGdex and shows the best matches for you to confirm.

1. Create a project on [Vercel](https://vercel.com) from this repo (it picks up `vercel.json` and `api/`).
2. Add environment variables in the Vercel project: `ANTHROPIC_API_KEY` (required), `IDENTIFY_MODEL` and `ALLOWED_ORIGIN` (optional).
3. For the mobile app, set `EXPO_PUBLIC_API_BASE_URL` in `.env` to your deployed URL. The website uses the same site, so it needs nothing.
4. Locally: `npx vercel dev` serves the API on `http://localhost:3000`.

Each scan costs a small amount of API usage. Before you share the app publicly, add rate limiting or sign-in to `api/identify.ts`, otherwise anyone who finds the URL can spend your key.

## Price data and terms

TickerMint is free for personal and non-commercial use if you show a visible **"Prices: TickerMint"** link next to prices (the app already does). Commercial use needs a paid plan. Check their current terms before launching publicly. Prices update once a day.

## Project layout

```
app/            screens (Expo Router): tabs for Collection, Scan, Search, Settings, plus card/[id]
src/lib/        pure logic with no React: API parsing, matching, history, collection math
src/theme/      design tokens and the light/dark provider
src/components/ shared UI pieces (flat, token-driven)
src/state/      collection context (persisted)
api/            server function for scanning
tests/          node:test unit tests
docs/           architecture and design notes
```

## Put it on GitHub and collaborate

```bash
git init -b main
git add .
git commit -m "Initial scaffold"
# create an empty repo on github.com (no README), then:
git remote add origin https://github.com/<you>/pokescan.git
git push -u origin main
```

Then, on GitHub:

1. **Settings → Collaborators**: invite your teammates.
2. **Settings → Branches**: add a rule for `main` that requires a pull request and the **CI** check to pass.
3. Commit `package-lock.json` (created by your first `npm install`) so CI installs the same versions for everyone.

How we work together is in [CONTRIBUTING.md](CONTRIBUTING.md).

## Known gaps

- Screens are untested on real devices; first run may need small fixes.
- TickerMint and TCGdex response shapes were written from their public docs. The parsers are defensive and tested against sample data, but verify against live responses (`https://api.tickermint.cards/openapi.json`).
- Scanning depends on photo quality; the confirm step is there because a misread is possible.
- No tests yet for screens. Good first contribution.
- `com.example.pokescan` is a placeholder bundle id; change it in `app.json` before publishing.

Pokémon and card names are trademarks of their owners. This project is not affiliated with Nintendo, Creatures Inc., GAME FREAK, The Pokémon Company, or TCGplayer.
