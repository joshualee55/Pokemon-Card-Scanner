# Contributing

Thanks for helping. The goal is small, reviewable changes that keep `main` working.

## Workflow

1. Pick or open an issue.
2. Branch from `main`: `feature/short-name`, `fix/short-name`, or `docs/short-name`.
3. Make the change. Keep it focused on one thing.
4. Run `npm run check` (typecheck and tests). Add or update a test when you change logic in `src/lib/` or `api/`.
5. Open a pull request using the template. Include a screenshot for any UI change, in **both light and dark**.
6. One approval and a green CI run are needed to merge. Squash-merge.

Commit messages: short, present tense, e.g. `Add price range selector`.

## Design rules (tests enforce the first three)

- Flat colors only. **No gradients.**
- **No purple or violet** anywhere.
- Text meets WCAG AA contrast in light and dark.
- Every color comes from `src/theme/tokens.ts`. Do not hard-code hex values in screens.
- One accent color (amber) for highlights; green and red are only for gains and losses.
- Plain language in the UI: name actions by what they do ("Add to collection"), and explain errors with how to fix them.

## Code rules

- Put logic that does not need React in `src/lib/`, with no imports from React Native, so it stays testable.
- Files in `src/lib/` may only import each other with `import type` (so tests run without a build step).
- Providers (prices, card data) stay inside their one file. UI code never builds provider URLs.
- Never put a secret in the app. Anything private belongs in `api/` with an environment variable.

## Reporting problems

Use the issue templates. For bad prices or wrong card matches, include the card name, set, number, and what you expected.
