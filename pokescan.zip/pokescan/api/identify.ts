/**
 * POST /api/identify   body: { image: <base64>, mediaType?: "image/jpeg" }
 * Returns: { is_pokemon_card: boolean, name: string|null, number: string|null, set: string|null }
 *
 * Runs on the server so your Anthropic API key never ships inside the app.
 * Deploy target: Vercel Functions (Node runtime). Any host that supports the Web Request/Response API works.
 */
const MAX_BASE64_CHARS = 6_000_000; // ~4.5 MB image
const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);

const PROMPT =
  'Read this photo of a Pokémon trading card. Respond with ONLY a JSON object, no other text: ' +
  '{"is_pokemon_card": boolean, "name": string|null, "number": string|null, "set": string|null}. ' +
  '"name" is the card name exactly as printed (include suffixes like ex, V, VMAX). ' +
  '"number" is the collector number printed at the bottom, like "199/165" or "SWSH123". ' +
  '"set" is the set name or symbol text if readable, otherwise null. Use null for anything you cannot read. Do not guess.';

function cors(): Record<string, string> {
  return {
    'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN ?? '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...cors() } });
}

export function OPTIONS(): Response {
  return new Response(null, { status: 204, headers: cors() });
}

export async function POST(request: Request): Promise<Response> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return json({ error: 'Server is missing ANTHROPIC_API_KEY' }, 500);

  let body: { image?: unknown; mediaType?: unknown };
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Body must be JSON' }, 400);
  }

  const image = typeof body.image === 'string' ? body.image : '';
  const mediaType = typeof body.mediaType === 'string' ? body.mediaType : 'image/jpeg';
  if (!image || image.length > MAX_BASE64_CHARS) return json({ error: 'Missing or oversized image' }, 400);
  if (!ALLOWED_TYPES.has(mediaType)) return json({ error: 'Unsupported image type' }, 400);

  const upstream = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: process.env.IDENTIFY_MODEL ?? 'claude-haiku-5-5',
      max_tokens: 200,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType, data: image } },
            { type: 'text', text: PROMPT },
          ],
        },
      ],
    }),
  });

  if (!upstream.ok) return json({ error: `Vision request failed (${upstream.status})` }, 502);

  const data = (await upstream.json()) as { content?: { type: string; text?: string }[] };
  const text = (data.content ?? []).filter((b) => b.type === 'text').map((b) => b.text ?? '').join('');
  const match = /\{[\s\S]*\}/.exec(text);
  if (!match) return json({ error: 'Could not read the card' }, 422);
  try {
    return json(JSON.parse(match[0]));
  } catch {
    return json({ error: 'Could not read the card' }, 422);
  }
}
