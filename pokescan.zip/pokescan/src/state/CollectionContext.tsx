import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { addOrIncrement, setQuantity } from '../lib/collection';
import { fetchHistory, findProduct, latestMarket } from '../lib/prices';
import type { CollectionItem } from '../lib/types';
import { readJson, writeJson } from '../storage/kv';

const KEY = 'pokescan:collection:v1';
const STALE_MS = 12 * 60 * 60 * 1000;

interface CollectionValue {
  items: CollectionItem[];
  ready: boolean;
  refreshing: boolean;
  add: (entry: Omit<CollectionItem, 'qty' | 'addedAt'>, qty?: number) => void;
  setQty: (id: string, printing: string | undefined, qty: number) => void;
  clear: () => void;
  refreshPrices: (opts?: { onlyStale?: boolean }) => Promise<void>;
}

const Ctx = createContext<CollectionValue | null>(null);

export function CollectionProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CollectionItem[]>([]);
  const [ready, setReady] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const ref = useRef<CollectionItem[]>([]);

  const commit = useCallback((next: CollectionItem[]) => {
    ref.current = next;
    setItems(next);
    writeJson(KEY, next);
  }, []);

  useEffect(() => {
    readJson<CollectionItem[]>(KEY, []).then((saved) => {
      ref.current = saved;
      setItems(saved);
      setReady(true);
    });
  }, []);

  const add = useCallback<CollectionValue['add']>((entry, qty = 1) => commit(addOrIncrement(ref.current, entry, qty)), [commit]);
  const setQty = useCallback<CollectionValue['setQty']>((id, printing, qty) => commit(setQuantity(ref.current, id, printing, qty)), [commit]);
  const clear = useCallback(() => commit([]), [commit]);

  const refreshPrices = useCallback<CollectionValue['refreshPrices']>(
    async (opts) => {
      setRefreshing(true);
      try {
        const snapshot = [...ref.current];
        for (const item of snapshot) {
          const age = item.lastPriceAt ? Date.now() - new Date(item.lastPriceAt).getTime() : Infinity;
          if (opts?.onlyStale && age < STALE_MS) continue;
          try {
            let productId = item.productId;
            if (!productId) {
              const product = await findProduct({ name: item.name, localId: item.number ?? '', officialTotal: item.officialTotal, setName: item.setName });
              productId = product?.productId;
            }
            if (!productId) continue;
            const history = await fetchHistory(productId);
            const price = latestMarket(history, item.printing);
            // Re-read the latest list so edits made while we were fetching are not lost.
            commit(
              ref.current.map((i) =>
                i.id === item.id && (i.printing ?? '') === (item.printing ?? '')
                  ? { ...i, productId, lastPrice: price, lastPriceAt: new Date().toISOString() }
                  : i,
              ),
            );
          } catch {
            // One bad card must not stop the rest. Its old price stays in place.
          }
        }
      } finally {
        setRefreshing(false);
      }
    },
    [commit],
  );

  const value = useMemo(() => ({ items, ready, refreshing, add, setQty, clear, refreshPrices }), [items, ready, refreshing, add, setQty, clear, refreshPrices]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCollection(): CollectionValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useCollection must be used inside <CollectionProvider>');
  return v;
}
