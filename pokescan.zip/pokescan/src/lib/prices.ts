import type { PriceHistory, PricePoint, PriceProduct } from './types';

/**
 * Price provider: TickerMint (daily TCGplayer market prices, history since Feb 2024).
 * Free for personal / non-commercial use with a visible "Prices: TickerMint" link.
 * Commercial use needs a paid plan. Keep this file the ONLY place that knows the provider,
 * so it can be swapped (Scrydex, PokeWallet, your own backend) without touching the UI.
 */
export const PRICE_API_BASE = 'https://api.tickermint.cards';
export const PRICE_ATTRIBUTION = 'Prices: TickerMint';

function toNumber(v: unknown): number | null {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : null;
}

function toRows(json: unknown): unknown[] {
  if (Array.isArray(json)) return json;
  if (typeof json === 'object' && json !== null) {
    const o = json as Record<string, unknown>;
    for (const key of ['results', 'data', 'products', 'items']) {
      if (Array.isArray(o[key])) return o[key] as unknown[];
    }
  }
  return [];
}

export function parseSearch(json: unknown): PriceProduct[] {
  const out: PriceProduct[] = [];
  for (const row of toRows(json)) {
    if (typeof row !== 'object' || row === null) continue;
    const r = row as Record<string, unknown>;
    const productId = r.product_id ?? r.productId ?? r.id;
    if (productId === undefined || productId === null) continue;
    const id = String(productId);
    const setValue = r.set ?? r.set_name ?? r.group_name;
    const setName =
      typeof setValue === 'string'
        ? setValue
        : typeof setValue === 'object' && setValue !== null
          ? String((setValue as Record<string, unknown>).name ?? '')
          : undefined;
    out.push({
      productId: id,
      name: String(r.name ?? ''),
      setName: setName || undefined,
      number: r.number !== undefined && r.number !== null ? String(r.number) : undefined,
      market: toNumber(r.market),
      url: typeof r.tickermint_url === 'string' ? r.tickermint_url : `https://tickermint.cards/card/${id}`,
    });
  }
  return out;
}

function leadingNumber(s: string | undefined): string | null {
  if (!s) return null;
  const m = /^\s*0*(\d+)/.exec(s);
  return m ? m[1] : null;
}

function normalise(s: string | undefined): string {
  return (s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

export interface WantedCard {
  name: string;
  localId: string;
  officialTotal?: number;
  setName?: string;
}

/**
 * Choose the product that is really this card. We would rather show "no price"
 * than the price of a different card, so a match needs the same collector number
 * AND either a matching name or a matching set.
 */
export function pickProduct(products: PriceProduct[], wanted: WantedCard): PriceProduct | null {
  const wantedNumber = leadingNumber(wanted.localId);
  const wantedName = normalise(wanted.name);
  const wantedSet = normalise(wanted.setName);
  let best: PriceProduct | null = null;
  let bestScore = 0;
  for (const p of products) {
    if (!wantedNumber || leadingNumber(p.number) !== wantedNumber) continue;
    let score = 2;
    const pn = normalise(p.name);
    if (pn && wantedName && (pn.includes(wantedName) || wantedName.includes(pn))) score += 2;
    const ps = normalise(p.setName);
    if (ps && wantedSet && (ps.includes(wantedSet) || wantedSet.includes(ps))) score += 2;
    if (wanted.officialTotal && p.number && p.number.includes(`/${wanted.officialTotal}`)) score += 1;
    if (score > bestScore) {
      best = p;
      bestScore = score;
    }
  }
  // number alone (score 2) is not enough; need name or set too
  return bestScore >= 4 ? best : null;
}

function parsePoints(rows: unknown): PricePoint[] {
  if (!Array.isArray(rows)) return [];
  const pts: PricePoint[] = [];
  for (const row of rows) {
    if (typeof row !== 'object' || row === null) continue;
    const r = row as Record<string, unknown>;
    const date = r.snapshot_date ?? r.date;
    if (typeof date !== 'string') continue;
    pts.push({ date: date.slice(0, 10), market: toNumber(r.market), low: toNumber(r.low) });
  }
  pts.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  return pts;
}

export function parseHistory(json: unknown): PriceHistory {
  const out: PriceHistory = {};
  if (Array.isArray(json)) {
    const pts = parsePoints(json);
    if (pts.length) out['Market'] = pts;
    return out;
  }
  if (typeof json !== 'object' || json === null) return out;
  const o = json as Record<string, unknown>;
  const container = typeof o.prices === 'object' && o.prices !== null && !Array.isArray(o.prices) ? (o.prices as Record<string, unknown>) : o;
  for (const [printing, rows] of Object.entries(container)) {
    const pts = parsePoints(rows);
    if (pts.length) out[printing] = pts;
  }
  return out;
}

async function getJson(url: string, timeoutMs = 15000): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`Price request failed (${res.status})`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function findProduct(card: WantedCard): Promise<PriceProduct | null> {
  const total = card.officialTotal ? `/${card.officialTotal}` : '';
  const q = `${card.name} ${card.localId}${total}`;
  const json = await getJson(`${PRICE_API_BASE}/products/search?q=${encodeURIComponent(q)}&game=pokemon`);
  return pickProduct(parseSearch(json), card);
}

export async function fetchHistory(productId: string): Promise<PriceHistory> {
  return parseHistory(await getJson(`${PRICE_API_BASE}/products/${encodeURIComponent(productId)}/prices`));
}

/** Latest known market price for a printing (falls back to the first printing). */
export function latestMarket(history: PriceHistory, printing?: string): number | null {
  const key = printing && history[printing] ? printing : Object.keys(history)[0];
  if (!key) return null;
  const pts = history[key];
  for (let i = pts.length - 1; i >= 0; i--) {
    if (pts[i].market !== null) return pts[i].market;
  }
  return null;
}
