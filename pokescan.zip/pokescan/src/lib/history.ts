import type { PricePoint } from './types';

export type RangeKey = '1M' | '3M' | '6M' | 'ALL';

const RANGE_DAYS: Record<RangeKey, number | null> = { '1M': 30, '3M': 90, '6M': 180, ALL: null };

export function filterRange(points: PricePoint[], range: RangeKey, today: Date = new Date()): PricePoint[] {
  const days = RANGE_DAYS[range];
  if (days === null) return points;
  const cutoff = new Date(today.getTime() - days * 86400000).toISOString().slice(0, 10);
  return points.filter((p) => p.date >= cutoff);
}

/** Percent change between the first and last point that have a market price. */
export function percentChange(points: PricePoint[]): number | null {
  const priced = points.filter((p) => p.market !== null) as (PricePoint & { market: number })[];
  if (priced.length < 2) return null;
  const first = priced[0].market;
  const last = priced[priced.length - 1].market;
  if (first === 0) return null;
  return ((last - first) / first) * 100;
}

export interface ChartGeometry {
  d: string;
  min: number;
  max: number;
  last: { x: number; y: number } | null;
}

/** Turn market prices into an SVG path inside a width x height box with padding. */
export function toChartPath(points: PricePoint[], width: number, height: number, pad = 8): ChartGeometry {
  const values = points.map((p) => p.market).filter((v): v is number => v !== null);
  if (values.length === 0) return { d: '', min: 0, max: 0, last: null };
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const innerW = width - pad * 2;
  const innerH = height - pad * 2;
  const priced = points.filter((p) => p.market !== null) as (PricePoint & { market: number })[];
  const n = priced.length;
  const coords = priced.map((p, i) => {
    const x = pad + (n === 1 ? innerW / 2 : (i / (n - 1)) * innerW);
    const y = pad + innerH - ((p.market - min) / span) * innerH;
    return { x, y };
  });
  const d = coords.map((c, i) => `${i === 0 ? 'M' : 'L'}${c.x.toFixed(1)} ${c.y.toFixed(1)}`).join(' ');
  return { d, min, max, last: coords[coords.length - 1] };
}
