import type { CollectionItem } from './types';

const same = (a: CollectionItem, id: string, printing?: string) => a.id === id && (a.printing ?? '') === (printing ?? '');

export function addOrIncrement(items: CollectionItem[], entry: Omit<CollectionItem, 'qty' | 'addedAt'>, qty = 1, now = new Date()): CollectionItem[] {
  const existing = items.find((i) => same(i, entry.id, entry.printing));
  if (existing) {
    return items.map((i) => (i === existing ? { ...i, ...entry, qty: i.qty + qty, addedAt: i.addedAt } : i));
  }
  return [...items, { ...entry, qty, addedAt: now.toISOString() }];
}

/** Set an exact quantity. A quantity of 0 or less removes the card. */
export function setQuantity(items: CollectionItem[], id: string, printing: string | undefined, qty: number): CollectionItem[] {
  if (qty <= 0) return items.filter((i) => !same(i, id, printing));
  return items.map((i) => (same(i, id, printing) ? { ...i, qty } : i));
}

export function totalCards(items: CollectionItem[]): number {
  return items.reduce((sum, i) => sum + i.qty, 0);
}

/** Sum of price x quantity. Cards with no price count as 0 and are reported separately. */
export function totalValue(items: CollectionItem[]): { value: number; unpriced: number } {
  let value = 0;
  let unpriced = 0;
  for (const i of items) {
    if (typeof i.lastPrice === 'number') value += i.lastPrice * i.qty;
    else unpriced += 1;
  }
  return { value: Math.round(value * 100) / 100, unpriced };
}

export function sortByValue(items: CollectionItem[]): CollectionItem[] {
  return [...items].sort((a, b) => (b.lastPrice ?? -1) * b.qty - (a.lastPrice ?? -1) * a.qty);
}
