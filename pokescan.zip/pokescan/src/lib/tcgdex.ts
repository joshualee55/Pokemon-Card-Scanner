import type { CardDetail, CardSummary } from './types';

/** TCGdex: free, no API key. https://tcgdex.dev */
export const TCGDEX_BASE = 'https://api.tcgdex.net/v2/en';

export function cardImage(base: string | undefined, quality: 'low' | 'high' = 'low'): string | undefined {
  return base ? `${base}/${quality}.webp` : undefined;
}

function asString(v: unknown): string | undefined {
  return typeof v === 'string' && v.length > 0 ? v : undefined;
}

export function parseSummaries(json: unknown): CardSummary[] {
  if (!Array.isArray(json)) return [];
  const out: CardSummary[] = [];
  for (const row of json) {
    if (typeof row !== 'object' || row === null) continue;
    const r = row as Record<string, unknown>;
    const id = asString(r.id);
    const name = asString(r.name);
    if (!id || !name) continue;
    out.push({ id, name, localId: String(r.localId ?? ''), image: asString(r.image) });
  }
  return out;
}

export function parseCard(json: unknown): CardDetail | null {
  if (typeof json !== 'object' || json === null) return null;
  const r = json as Record<string, unknown>;
  const id = asString(r.id);
  const name = asString(r.name);
  if (!id || !name) return null;
  const set = (typeof r.set === 'object' && r.set !== null ? r.set : {}) as Record<string, unknown>;
  const counts = (typeof set.cardCount === 'object' && set.cardCount !== null ? set.cardCount : {}) as Record<string, unknown>;
  const official = Number(counts.official);
  return {
    id,
    name,
    localId: String(r.localId ?? ''),
    image: asString(r.image),
    setName: asString(set.name),
    setId: asString(set.id),
    officialTotal: Number.isFinite(official) && official > 0 ? official : undefined,
    rarity: asString(r.rarity),
    illustrator: asString(r.illustrator),
    category: asString(r.category),
  };
}

async function getJson(url: string, timeoutMs = 15000): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) throw new Error(`TCGdex request failed (${res.status})`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function searchCards(name: string, limit = 40): Promise<CardSummary[]> {
  const q = name.trim();
  if (q.length < 2) return [];
  const url = `${TCGDEX_BASE}/cards?name=${encodeURIComponent(q)}`;
  const cards = parseSummaries(await getJson(url));
  return cards.slice(0, limit);
}

export async function getCard(id: string): Promise<CardDetail | null> {
  return parseCard(await getJson(`${TCGDEX_BASE}/cards/${encodeURIComponent(id)}`));
}
