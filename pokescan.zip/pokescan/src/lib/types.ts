/** Shared types. Keep this file free of runtime code so it can be imported anywhere. */

export interface CardSummary {
  id: string;
  localId: string;
  name: string;
  /** Base image URL from TCGdex (append /low.webp or /high.webp). */
  image?: string;
}

export interface CardDetail extends CardSummary {
  setName?: string;
  setId?: string;
  /** Printed total, the "165" in "199/165". */
  officialTotal?: number;
  rarity?: string;
  illustrator?: string;
  category?: string;
}

export interface PricePoint {
  /** ISO date, YYYY-MM-DD */
  date: string;
  market: number | null;
  low: number | null;
}

/** printing name (e.g. "Holofoil") -> daily points, oldest first */
export type PriceHistory = Record<string, PricePoint[]>;

export interface PriceProduct {
  productId: string;
  name: string;
  setName?: string;
  number?: string;
  market: number | null;
  url: string;
}

export interface CollectionItem {
  /** TCGdex card id, e.g. "swsh3-136" */
  id: string;
  name: string;
  setName?: string;
  number?: string;
  officialTotal?: number;
  image?: string;
  printing?: string;
  qty: number;
  productId?: string;
  lastPrice?: number | null;
  lastPriceAt?: string;
  addedAt: string;
}

export interface IdentifyHint {
  name: string;
  number?: string | null;
  set?: string | null;
}
