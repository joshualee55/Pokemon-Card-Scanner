import type { CardSummary, IdentifyHint } from './types';

/** Parse the JSON the scan endpoint returns. Anything unexpected becomes null. */
export function parseIdentify(json: unknown): IdentifyHint | null {
  if (typeof json !== 'object' || json === null) return null;
  const r = json as Record<string, unknown>;
  if (r.is_pokemon_card === false) return null;
  const name = typeof r.name === 'string' ? r.name.trim() : '';
  if (!name) return null;
  return {
    name,
    number: typeof r.number === 'string' && r.number.trim() ? r.number.trim() : null,
    set: typeof r.set === 'string' && r.set.trim() ? r.set.trim() : null,
  };
}

function leading(s: string | null | undefined): string | null {
  if (!s) return null;
  const m = /^\s*0*(\d+)/.exec(s);
  return m ? m[1] : null;
}

/** Put candidates whose collector number matches the scan first; keep everything else after. */
export function rankCandidates(candidates: CardSummary[], hint: IdentifyHint): CardSummary[] {
  const wanted = leading(hint.number);
  const score = (c: CardSummary) => (wanted && leading(c.localId) === wanted ? 1 : 0);
  return [...candidates].sort((a, b) => score(b) - score(a));
}

/** Send a base64 JPEG to the scan endpoint (see api/identify.ts). */
export async function identifyCard(apiBase: string, imageBase64: string, mediaType = 'image/jpeg'): Promise<IdentifyHint | null> {
  const res = await fetch(`${apiBase.replace(/\/$/, '')}/api/identify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ image: imageBase64, mediaType }),
  });
  if (!res.ok) throw new Error(`Scan failed (${res.status})`);
  return parseIdentify(await res.json());
}
