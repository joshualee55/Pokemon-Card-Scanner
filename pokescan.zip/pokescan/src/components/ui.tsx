import React from 'react';
import { Pressable, StyleSheet, Text, View, type StyleProp, type TextProps, type TextStyle, type ViewStyle } from 'react-native';
import { Image } from 'expo-image';
import { SafeAreaView } from 'react-native-safe-area-context';
import { font, radius, space } from '../theme/tokens';
import { useTheme } from '../theme/ThemeProvider';

type Variant = keyof typeof font;

export function Txt({ variant = 'body', muted, style, ...rest }: TextProps & { variant?: Variant; muted?: boolean; style?: StyleProp<TextStyle> }) {
  const { colors } = useTheme();
  return <Text {...rest} style={[font[variant], { color: muted ? colors.textMuted : colors.text, fontVariant: ['tabular-nums'] }, style]} />;
}

export function Screen({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme();
  return (
    <SafeAreaView edges={['top']} style={[{ flex: 1, backgroundColor: colors.bg }, style]}>
      {children}
    </SafeAreaView>
  );
}

export function Button({ label, onPress, variant = 'primary', disabled, style }: { label: string; onPress: () => void; variant?: 'primary' | 'secondary'; disabled?: boolean; style?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme();
  const primary = variant === 'primary';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: primary ? colors.accent : colors.surfaceAlt,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      <Text style={[font.heading, { color: primary ? colors.onAccent : colors.text }]}>{label}</Text>
    </Pressable>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: { value: T; label: string }[]; value: T; onChange: (v: T) => void }) {
  const { colors } = useTheme();
  return (
    <View style={[styles.segmented, { backgroundColor: colors.surfaceAlt }]} accessibilityRole="tablist">
      {options.map((o) => {
        const selected = o.value === value;
        return (
          <Pressable
            key={o.value}
            accessibilityRole="tab"
            accessibilityState={{ selected }}
            onPress={() => onChange(o.value)}
            style={[styles.segment, selected && { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: StyleSheet.hairlineWidth }]}
          >
            <Text style={[font.caption, { color: selected ? colors.text : colors.textMuted, fontWeight: selected ? '600' : '400' }]}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function CardThumb({ uri, width = 44 }: { uri?: string; width?: number }) {
  const { colors } = useTheme();
  const height = Math.round(width * 1.4);
  return (
    <View style={{ width, height, borderRadius: radius.sm / 2, backgroundColor: colors.surfaceAlt, overflow: 'hidden' }}>
      {uri ? <Image source={{ uri }} style={{ width, height }} contentFit="cover" transition={0} accessibilityIgnoresInvertColors /> : null}
    </View>
  );
}

export function Divider() {
  const { colors } = useTheme();
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: colors.border }} />;
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <View style={styles.empty}>
      <Txt variant="heading">{title}</Txt>
      <Txt muted style={{ textAlign: 'center', maxWidth: 280 }}>{body}</Txt>
      {action}
    </View>
  );
}

const styles = StyleSheet.create({
  button: { minHeight: 48, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center', paddingHorizontal: space.xl },
  segmented: { flexDirection: 'row', borderRadius: radius.md, padding: 3, gap: 2 },
  segment: { flex: 1, minHeight: 34, alignItems: 'center', justifyContent: 'center', borderRadius: radius.md - 3, borderWidth: 0, paddingHorizontal: space.sm },
  empty: { alignItems: 'center', gap: space.md, paddingVertical: space.xxl * 2, paddingHorizontal: space.xl },
});
