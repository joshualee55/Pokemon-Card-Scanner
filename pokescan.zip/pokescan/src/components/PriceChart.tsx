import React, { useState } from 'react';
import { View, type LayoutChangeEvent } from 'react-native';
import Svg, { Circle, Line, Path } from 'react-native-svg';
import { toChartPath } from '../lib/history';
import type { PricePoint } from '../lib/types';
import { useTheme } from '../theme/ThemeProvider';

export function PriceChart({ points, height = 160, rising }: { points: PricePoint[]; height?: number; rising: boolean | null }) {
  const { colors } = useTheme();
  const [width, setWidth] = useState(0);
  const onLayout = (e: LayoutChangeEvent) => setWidth(Math.floor(e.nativeEvent.layout.width));
  const geometry = width > 0 ? toChartPath(points, width, height, 10) : null;
  const stroke = rising === null ? colors.text : rising ? colors.up : colors.down;

  return (
    <View onLayout={onLayout} style={{ height }} accessibilityRole="image" accessibilityLabel="Price history chart">
      {geometry && geometry.d ? (
        <Svg width={width} height={height}>
          <Line x1={0} y1={height - 1} x2={width} y2={height - 1} stroke={colors.border} strokeWidth={1} />
          <Path d={geometry.d} stroke={stroke} strokeWidth={2} fill="none" strokeLinejoin="round" strokeLinecap="round" />
          {geometry.last ? <Circle cx={geometry.last.x} cy={geometry.last.y} r={4} fill={stroke} /> : null}
        </Svg>
      ) : null}
    </View>
  );
}
