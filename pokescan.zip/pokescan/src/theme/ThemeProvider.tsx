import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { readJson, writeJson } from '../storage/kv';
import { darkColors, lightColors, type Colors } from './tokens';

export type ThemePreference = 'system' | 'light' | 'dark';

interface ThemeValue {
  colors: Colors;
  mode: 'light' | 'dark';
  preference: ThemePreference;
  setPreference: (p: ThemePreference) => void;
}

const KEY = 'pokescan:theme:v1';
const ThemeContext = createContext<ThemeValue>({
  colors: darkColors,
  mode: 'dark',
  preference: 'system',
  setPreference: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [preference, setPreferenceState] = useState<ThemePreference>('system');

  useEffect(() => {
    readJson<ThemePreference>(KEY, 'system').then(setPreferenceState);
  }, []);

  const value = useMemo<ThemeValue>(() => {
    const mode: 'light' | 'dark' = preference === 'system' ? (system === 'light' ? 'light' : 'dark') : preference;
    return {
      colors: mode === 'light' ? lightColors : darkColors,
      mode,
      preference,
      setPreference: (p) => {
        setPreferenceState(p);
        writeJson(KEY, p);
      },
    };
  }, [preference, system]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeValue {
  return useContext(ThemeContext);
}
