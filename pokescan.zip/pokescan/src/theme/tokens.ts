/**
 * Design tokens. Rules (enforced by tests/theme.test.ts):
 *  - flat colors only, no gradients anywhere
 *  - no purple/violet hues
 *  - body text and muted text meet WCAG AA contrast in both themes
 * One accent (amber) does all the highlighting; gains are green, losses are red.
 */
export interface Colors {
  bg: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  text: string;
  textMuted: string;
  accent: string;
  onAccent: string;
  accentText: string;
  up: string;
  down: string;
}

export const lightColors: Colors = {
  bg: '#F5F6F4',
  surface: '#FFFFFF',
  surfaceAlt: '#ECEEEA',
  border: '#DEE1DC',
  text: '#101418',
  textMuted: '#5B6470',
  accent: '#F2B230',
  onAccent: '#17120A',
  accentText: '#8A5A00',
  up: '#17794A',
  down: '#C0392B',
};

export const darkColors: Colors = {
  bg: '#0D1013',
  surface: '#161A1E',
  surfaceAlt: '#1E2328',
  border: '#2A3037',
  text: '#F1F3F4',
  textMuted: '#9AA4AE',
  accent: '#F2B230',
  onAccent: '#17120A',
  accentText: '#F2B230',
  up: '#3DD68C',
  down: '#FF6B6B',
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;
export const radius = { sm: 8, md: 12, lg: 16, pill: 999 } as const;

export const font = {
  /** Big portfolio / card value */
  display: { fontSize: 40, lineHeight: 46, fontWeight: '700' as const, letterSpacing: -0.8 },
  title: { fontSize: 22, lineHeight: 28, fontWeight: '700' as const, letterSpacing: -0.3 },
  heading: { fontSize: 17, lineHeight: 22, fontWeight: '600' as const },
  body: { fontSize: 15, lineHeight: 21, fontWeight: '400' as const },
  caption: { fontSize: 13, lineHeight: 18, fontWeight: '400' as const },
};
