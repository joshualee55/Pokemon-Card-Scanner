---
name: Feature
about: Suggest an improvement
labels: enhancement
---

**What problem does this solve for someone collecting cards?**

**What should it do?**

**Anything it should not do?**
