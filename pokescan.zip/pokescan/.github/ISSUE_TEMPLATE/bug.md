---
name: Bug
about: Something is wrong or broken
labels: bug
---

**What happened**

**What you expected**

**Steps to reproduce** (include the card name, set, and number if it is about a card or price)

**Where** (web, iOS, Android) and **theme** (light or dark)
