## What changed and why

## How to check it

- [ ] `npm run check` passes
- [ ] Screenshots attached for UI changes (light and dark)
- [ ] No hard-coded colors, no gradients, no purple
- [ ] Tests added or updated for logic changes
