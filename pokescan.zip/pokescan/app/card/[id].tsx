import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Linking, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { Image } from 'expo-image';
import { Stack, useLocalSearchParams } from 'expo-router';
import { PriceChart } from '../../src/components/PriceChart';
import { Button, Divider, Segmented, Txt } from '../../src/components/ui';
import { formatDate, formatPercent, formatUsd } from '../../src/lib/format';
import { filterRange, percentChange, type RangeKey } from '../../src/lib/history';
import { PRICE_ATTRIBUTION, fetchHistory, findProduct, latestMarket } from '../../src/lib/prices';
import { cardImage, getCard } from '../../src/lib/tcgdex';
import type { CardDetail, PriceHistory, PriceProduct } from '../../src/lib/types';
import { useCollection } from '../../src/state/CollectionContext';
import { useTheme } from '../../src/theme/ThemeProvider';
import { radius, space } from '../../src/theme/tokens';

const RANGES: { value: RangeKey; label: string }[] = [
  { value: '1M', label: '1M' },
  { value: '3M', label: '3M' },
  { value: '6M', label: '6M' },
  { value: 'ALL', label: 'All' },
];

export default function CardScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors } = useTheme();
  const { items, add, setQty } = useCollection();

  const [card, setCard] = useState<CardDetail | null>(null);
  const [product, setProduct] = useState<PriceProduct | null>(null);
  const [history, setHistory] = useState<PriceHistory>({});
  const [loading, setLoading] = useState(true);
  const [pricesLoading, setPricesLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [printing, setPrinting] = useState<string | undefined>(undefined);
  const [range, setRange] = useState<RangeKey>('3M');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setPricesLoading(true);
    setError(null);
    (async () => {
      try {
        const found = await getCard(String(id));
        if (cancelled) return;
        if (!found) {
          setError('This card could not be found.');
          return;
        }
        setCard(found);
        setLoading(false);
        const match = await findProduct({ name: found.name, localId: found.localId, officialTotal: found.officialTotal, setName: found.setName });
        if (cancelled) return;
        setProduct(match);
        if (match) {
          const h = await fetchHistory(match.productId);
          if (cancelled) return;
          setHistory(h);
          setPrinting((current) => current ?? Object.keys(h)[0]);
        }
      } catch {
        if (!cancelled) setError('Could not load this card. Check your connection and try again.');
      } finally {
        if (!cancelled) {
          setLoading(false);
          setPricesLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [id]);

  const printings = Object.keys(history);
  const series = printing ? history[printing] ?? [] : [];
  const visible = useMemo(() => filterRange(series, range), [series, range]);
  const change = percentChange(visible);
  const price = latestMarket(history, printing);
  const owned = items.find((i) => i.id === card?.id && (i.printing ?? '') === (printing ?? ''));
  const lastPoint = series.length ? series[series.length - 1] : undefined;

  function addToCollection() {
    if (!card) return;
    add({
      id: card.id,
      name: card.name,
      setName: card.setName,
      number: card.localId,
      officialTotal: card.officialTotal,
      image: card.image,
      printing,
      productId: product?.productId,
      lastPrice: price,
      lastPriceAt: new Date().toISOString(),
    });
  }

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.bg }]}>
        <ActivityIndicator color={colors.textMuted} />
      </View>
    );
  }

  if (error || !card) {
    return (
      <View style={[styles.center, { backgroundColor: colors.bg }]}>
        <Txt style={{ color: colors.down, textAlign: 'center', paddingHorizontal: space.xl }}>{error ?? 'This card could not be found.'}</Txt>
      </View>
    );
  }

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={styles.pad}>
      <Stack.Screen options={{ title: card.name }} />

      <View style={styles.hero}>
        {card.image ? (
          <Image source={{ uri: cardImage(card.image, 'high') }} style={styles.image} contentFit="contain" accessibilityLabel={`${card.name} card`} />
        ) : (
          <View style={[styles.image, { backgroundColor: colors.surfaceAlt }]} />
        )}
      </View>

      <View style={{ gap: space.xs }}>
        <Txt variant="title">{card.name}</Txt>
        <Txt muted>
          {[card.setName, `#${card.localId}${card.officialTotal ? `/${card.officialTotal}` : ''}`, card.rarity].filter(Boolean).join(' · ')}
        </Txt>
      </View>

      <View style={{ gap: space.xs }}>
        <Txt variant="display">{pricesLoading ? '…' : formatUsd(price)}</Txt>
        {!pricesLoading && price !== null ? (
          <Txt variant="caption" style={{ color: change === null ? colors.textMuted : change >= 0 ? colors.up : colors.down }}>
            {change === null ? 'Not enough history to show a change' : `${formatPercent(change)} over ${range === 'ALL' ? 'all time' : range}`}
          </Txt>
        ) : null}
        {!pricesLoading && price === null ? (
          <Txt variant="caption" muted>
            No matching price found for this card.
          </Txt>
        ) : null}
      </View>

      {printings.length > 1 ? (
        <Segmented value={printing ?? printings[0]} onChange={setPrinting} options={printings.map((p) => ({ value: p, label: p }))} />
      ) : null}

      {series.length > 0 ? (
        <View style={{ gap: space.md }}>
          <PriceChart points={visible} rising={change === null ? null : change >= 0} />
          <Segmented value={range} onChange={setRange} options={RANGES} />
          {lastPoint ? (
            <Txt variant="caption" muted>
              Low {formatUsd(lastPoint.low)} · Market {formatUsd(lastPoint.market)} · as of {formatDate(lastPoint.date)}
            </Txt>
          ) : null}
        </View>
      ) : null}

      <Divider />

      {owned ? (
        <View style={styles.qtyRow}>
          <Txt variant="heading" style={{ flex: 1 }}>In your collection</Txt>
          <Pressable accessibilityRole="button" accessibilityLabel="Remove one" onPress={() => setQty(owned.id, owned.printing, owned.qty - 1)} style={[styles.stepper, { backgroundColor: colors.surfaceAlt }]}>
            <Txt variant="heading">−</Txt>
          </Pressable>
          <Txt variant="heading" style={{ minWidth: 28, textAlign: 'center' }}>{owned.qty}</Txt>
          <Pressable accessibilityRole="button" accessibilityLabel="Add one" onPress={() => setQty(owned.id, owned.printing, owned.qty + 1)} style={[styles.stepper, { backgroundColor: colors.surfaceAlt }]}>
            <Txt variant="heading">+</Txt>
          </Pressable>
        </View>
      ) : (
        <Button label="Add to collection" onPress={addToCollection} />
      )}

      {product ? (
        <Txt variant="caption" muted style={{ textDecorationLine: 'underline' }} accessibilityRole="link" onPress={() => Linking.openURL(product.url)}>
          {PRICE_ATTRIBUTION}
        </Txt>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  pad: { padding: space.lg, gap: space.lg, paddingBottom: space.xxl * 2 },
  hero: { alignItems: 'center' },
  image: { width: 240, height: 336, borderRadius: radius.md },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  stepper: { width: 44, height: 44, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
});
