import React from 'react';
import { Linking, ScrollView, StyleSheet, View } from 'react-native';
import { Button, Divider, Screen, Segmented, Txt } from '../../src/components/ui';
import { confirmDestructive } from '../../src/components/confirm';
import { PRICE_ATTRIBUTION } from '../../src/lib/prices';
import { useCollection } from '../../src/state/CollectionContext';
import { useTheme, type ThemePreference } from '../../src/theme/ThemeProvider';
import { space } from '../../src/theme/tokens';

export default function SettingsScreen() {
  const { preference, setPreference } = useTheme();
  const { items, clear } = useCollection();

  async function onClear() {
    const ok = await confirmDestructive('Clear collection?', `This removes all ${items.length} saved cards from this device.`, 'Clear');
    if (ok) clear();
  }

  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.pad}>
        <Txt variant="title">Settings</Txt>

        <View style={styles.group}>
          <Txt variant="heading">Appearance</Txt>
          <Segmented<ThemePreference>
            value={preference}
            onChange={setPreference}
            options={[
              { value: 'system', label: 'System' },
              { value: 'light', label: 'Light' },
              { value: 'dark', label: 'Dark' },
            ]}
          />
        </View>

        <Divider />

        <View style={styles.group}>
          <Txt variant="heading">Your data</Txt>
          <Txt muted>Your collection is saved on this device only. Clearing it cannot be undone.</Txt>
          <Button label="Clear collection" variant="secondary" onPress={onClear} disabled={items.length === 0} />
        </View>

        <Divider />

        <View style={styles.group}>
          <Txt variant="heading">Data sources</Txt>
          <Txt muted>Card data and images: TCGdex. Prices are daily TCGplayer market prices.</Txt>
          <Txt style={{ textDecorationLine: 'underline' }} accessibilityRole="link" onPress={() => Linking.openURL('https://tickermint.cards')}>
            {PRICE_ATTRIBUTION}
          </Txt>
          <Txt variant="caption" muted>
            PokeScan is not affiliated with Nintendo, Creatures Inc., GAME FREAK, The Pokémon Company, or TCGplayer. Pokémon and card names are trademarks of their owners.
          </Txt>
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  pad: { padding: space.lg, gap: space.xl },
  group: { gap: space.md },
});
