import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { CardThumb, Divider, EmptyState, Screen, Txt } from '../../src/components/ui';
import { cardImage, searchCards } from '../../src/lib/tcgdex';
import type { CardSummary } from '../../src/lib/types';
import { useTheme } from '../../src/theme/ThemeProvider';
import { font, radius, space } from '../../src/theme/tokens';

export default function SearchScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<CardSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setResults([]);
      setError(null);
      return;
    }
    let cancelled = false;
    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        const found = await searchCards(q);
        if (!cancelled) setResults(found);
      } catch {
        if (!cancelled) setError('Could not reach the card database. Check your connection and try again.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  return (
    <Screen>
      <View style={styles.top}>
        <Txt variant="title">Search</Txt>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Card name, like Charizard ex"
          placeholderTextColor={colors.textMuted}
          autoCapitalize="none"
          autoCorrect={false}
          clearButtonMode="while-editing"
          accessibilityLabel="Search cards by name"
          style={[font.body, styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }]}
        />
      </View>
      {loading ? <ActivityIndicator color={colors.textMuted} style={{ marginTop: space.lg }} /> : null}
      {error ? <Txt style={{ color: colors.down, paddingHorizontal: space.lg }}>{error}</Txt> : null}
      <FlatList
        data={results}
        keyExtractor={(c) => c.id}
        keyboardShouldPersistTaps="handled"
        ItemSeparatorComponent={Divider}
        ListEmptyComponent={
          !loading && !error && query.trim().length >= 2 ? (
            <EmptyState title="No matches" body="Try a shorter name, or check the spelling." />
          ) : null
        }
        renderItem={({ item }) => (
          <Pressable accessibilityRole="button" onPress={() => router.push(`/card/${item.id}`)} style={styles.row}>
            <CardThumb uri={cardImage(item.image, 'low')} />
            <View style={{ flex: 1 }}>
              <Txt variant="heading" numberOfLines={1}>{item.name}</Txt>
              <Txt variant="caption" muted>#{item.localId} · {item.id.split('-')[0]}</Txt>
            </View>
          </Pressable>
        )}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  top: { paddingHorizontal: space.lg, paddingTop: space.lg, gap: space.md, paddingBottom: space.md },
  input: { minHeight: 48, borderWidth: 1, borderRadius: radius.md, paddingHorizontal: space.md },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, paddingVertical: space.md },
});
