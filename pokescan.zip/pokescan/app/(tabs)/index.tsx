import React, { useEffect, useMemo } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Button, CardThumb, Divider, EmptyState, Screen, Txt } from '../../src/components/ui';
import { sortByValue, totalCards, totalValue } from '../../src/lib/collection';
import { formatUsd } from '../../src/lib/format';
import { cardImage } from '../../src/lib/tcgdex';
import type { CollectionItem } from '../../src/lib/types';
import { useCollection } from '../../src/state/CollectionContext';
import { useTheme } from '../../src/theme/ThemeProvider';
import { space } from '../../src/theme/tokens';

export default function CollectionScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const { items, ready, refreshing, refreshPrices } = useCollection();

  useEffect(() => {
    if (ready && items.length > 0) refreshPrices({ onlyStale: true });
    // Only when the saved collection first loads.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready]);

  const sorted = useMemo(() => sortByValue(items), [items]);
  const { value, unpriced } = totalValue(items);

  const header = (
    <View style={styles.header}>
      <Txt muted>Portfolio value</Txt>
      <Txt variant="display">{formatUsd(value)}</Txt>
      <Txt variant="caption" muted>
        {totalCards(items)} cards · {items.length} unique
        {unpriced > 0 ? ` · ${unpriced} without a price` : ''}
      </Txt>
    </View>
  );

  const renderItem = ({ item }: { item: CollectionItem }) => (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${item.name}, open details`}
      onPress={() => router.push(`/card/${item.id}`)}
      style={styles.row}
    >
      <CardThumb uri={cardImage(item.image, 'low')} />
      <View style={{ flex: 1, gap: 2 }}>
        <Txt variant="heading" numberOfLines={1}>{item.name}</Txt>
        <Txt variant="caption" muted numberOfLines={1}>
          {[item.setName, item.number ? `#${item.number}` : null, item.printing].filter(Boolean).join(' · ')}
        </Txt>
      </View>
      <View style={{ alignItems: 'flex-end', gap: 2 }}>
        <Txt variant="heading">{formatUsd(typeof item.lastPrice === 'number' ? item.lastPrice * item.qty : null)}</Txt>
        <Txt variant="caption" muted>{item.qty > 1 ? `${item.qty} × ${formatUsd(item.lastPrice)}` : `Qty ${item.qty}`}</Txt>
      </View>
    </Pressable>
  );

  return (
    <Screen>
      <FlatList
        data={sorted}
        keyExtractor={(i) => `${i.id}|${i.printing ?? ''}`}
        renderItem={renderItem}
        ItemSeparatorComponent={Divider}
        ListHeaderComponent={header}
        ListEmptyComponent={
          ready ? (
            <EmptyState
              title="No cards yet"
              body="Scan a card or search by name to add your first one."
              action={<Button label="Scan a card" onPress={() => router.push('/scan')} />}
            />
          ) : null
        }
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => refreshPrices()} tintColor={colors.textMuted} />}
        contentContainerStyle={{ paddingBottom: space.xxl }}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: space.lg, paddingTop: space.xl, paddingBottom: space.xl, gap: space.xs },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, paddingVertical: space.md },
});
