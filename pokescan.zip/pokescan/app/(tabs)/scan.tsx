import React, { useRef, useState } from 'react';
import { ActivityIndicator, Platform, Pressable, StyleSheet, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import { Button, CardThumb, Divider, Screen, Txt } from '../../src/components/ui';
import { identifyCard, rankCandidates } from '../../src/lib/identify';
import { cardImage, searchCards } from '../../src/lib/tcgdex';
import type { CardSummary, IdentifyHint } from '../../src/lib/types';
import { useTheme } from '../../src/theme/ThemeProvider';
import { radius, space } from '../../src/theme/tokens';

const API_BASE = process.env.EXPO_PUBLIC_API_BASE_URL ?? '';
// On the web build the API lives on the same site, so a relative URL works.
const SCAN_CONFIGURED = API_BASE.length > 0 || Platform.OS === 'web';

export default function ScanScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<CameraView>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hint, setHint] = useState<IdentifyHint | null>(null);
  const [matches, setMatches] = useState<CardSummary[] | null>(null);

  async function identify(base64: string) {
    setBusy(true);
    setError(null);
    setMatches(null);
    try {
      const found = await identifyCard(API_BASE, base64);
      if (!found) {
        setHint(null);
        setError('That does not look like a Pokémon card. Fill the frame with the front of one card and try again.');
        return;
      }
      setHint(found);
      const candidates = await searchCards(found.name);
      setMatches(rankCandidates(candidates, found).slice(0, 8));
    } catch {
      setError('Scanning failed. Check your connection, or use Search to find the card by name.');
    } finally {
      setBusy(false);
    }
  }

  async function takePhoto() {
    const photo = await cameraRef.current?.takePictureAsync({ base64: true, quality: 0.6 });
    if (photo?.base64) await identify(photo.base64);
  }

  async function choosePhoto() {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], base64: true, quality: 0.6 });
    const asset = result.canceled ? null : result.assets[0];
    if (asset?.base64) await identify(asset.base64);
  }

  if (!SCAN_CONFIGURED) {
    return (
      <Screen>
        <View style={styles.pad}>
          <Txt variant="title">Scan</Txt>
          <Txt muted>
            Scanning needs the scan service. Set EXPO_PUBLIC_API_BASE_URL in your .env file (see the README), or find cards with Search for now.
          </Txt>
          <Button label="Go to Search" onPress={() => router.push('/search')} />
        </View>
      </Screen>
    );
  }

  if (!permission) return <Screen><View style={styles.pad} /></Screen>;

  if (!permission.granted) {
    return (
      <Screen>
        <View style={styles.pad}>
          <Txt variant="title">Scan</Txt>
          <Txt muted>PokeScan needs the camera to read your cards. Photos are only used to identify the card.</Txt>
          <Button label="Allow camera" onPress={requestPermission} />
          <Button label="Choose a photo instead" variant="secondary" onPress={choosePhoto} />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.pad}>
        <Txt variant="title">Scan</Txt>
        <View style={[styles.camera, { borderColor: colors.border }]}>
          <CameraView ref={cameraRef} style={StyleSheet.absoluteFill} facing="back" />
          <View pointerEvents="none" style={[styles.frame, { borderColor: colors.accent }]} />
        </View>
        <Txt variant="caption" muted>Fit one card inside the frame, flat and well lit.</Txt>
        <View style={{ flexDirection: 'row', gap: space.md }}>
          <Button label={busy ? 'Reading…' : 'Scan card'} onPress={takePhoto} disabled={busy} style={{ flex: 1 }} />
          <Button label="Photo" variant="secondary" onPress={choosePhoto} disabled={busy} />
        </View>
        {busy ? <ActivityIndicator color={colors.textMuted} /> : null}
        {error ? <Txt style={{ color: colors.down }}>{error}</Txt> : null}
        {hint && matches ? (
          <View style={{ gap: space.sm }}>
            <Txt muted>
              Read “{hint.name}”{hint.number ? ` #${hint.number}` : ''}. Pick the right card:
            </Txt>
            {matches.length === 0 ? <Txt>No matches found. Try Search.</Txt> : null}
            {matches.map((c, i) => (
              <View key={c.id}>
                {i > 0 ? <Divider /> : null}
                <Pressable accessibilityRole="button" onPress={() => router.push(`/card/${c.id}`)} style={styles.match}>
                  <CardThumb uri={cardImage(c.image, 'low')} width={36} />
                  <View style={{ flex: 1 }}>
                    <Txt variant="heading" numberOfLines={1}>{c.name}</Txt>
                    <Txt variant="caption" muted>#{c.localId} · {c.id.split('-')[0]}</Txt>
                  </View>
                </Pressable>
              </View>
            ))}
          </View>
        ) : null}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  pad: { padding: space.lg, gap: space.md },
  camera: { height: 300, borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1 },
  frame: { position: 'absolute', top: 24, bottom: 24, left: '24%', right: '24%', borderWidth: 2, borderRadius: radius.md },
  match: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: space.sm },
});
