# Design

Reference: Collectr's calm, number-first layout. Function reference: TCGplayer's price and history views.

## Principles

- The number is the hero: portfolio value and card price are the largest text on their screens.
- Flat surfaces separated by thin borders and spacing. No gradients, no shadows doing decoration.
- One accent (amber) for the primary action and the active tab. Green and red are reserved for gains and losses.
- Same layout in light and dark; only tokens change.

## Tokens (`src/theme/tokens.ts`)

| Token | Light | Dark |
|---|---|---|
| bg | #F5F6F4 | #0D1013 |
| surface | #FFFFFF | #161A1E |
| surfaceAlt | #ECEEEA | #1E2328 |
| border | #DEE1DC | #2A3037 |
| text | #101418 | #F1F3F4 |
| textMuted | #5B6470 | #9AA4AE |
| accent | #F2B230 | #F2B230 |
| accentText | #8A5A00 | #F2B230 |
| up | #17794A | #3DD68C |
| down | #C0392B | #FF6B6B |

Type: system font, tabular numerals for all prices. Scale: display 40, title 22, heading 17, body 15, caption 13.

## Screens

Collection (value, list) · Scan (camera, confirm matches) · Search · Settings (theme, data) · Card (image, price, printing, chart, range, add).
