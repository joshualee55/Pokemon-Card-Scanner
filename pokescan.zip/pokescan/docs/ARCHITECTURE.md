# Architecture

```
Scan photo ──► api/identify.ts (server, holds the key) ──► { name, number, set }
                                                              │
                                   TCGdex search by name ◄────┘
                                          │  rank by collector number
                                          ▼
                              user confirms the card
                                          │
                      ┌───────────────────┴──────────────────┐
                      ▼                                      ▼
            TCGdex card detail                    TickerMint search → product id
          (set, printed total, image)             → daily price history per printing
                      └───────────────────┬──────────────────┘
                                          ▼
                             card screen: price, chart, add
                                          ▼
                    collection saved on device (AsyncStorage)
```

## Decisions

- **Confirm step after scanning.** A vision model can misread a number. The user picks from ranked matches instead of trusting one guess.
- **Refuse to guess prices.** `pickProduct` needs a matching collector number plus a matching name or set. A missing price is better than a wrong one.
- **Providers are isolated.** `src/lib/tcgdex.ts` and `src/lib/prices.ts` are the only files that know a vendor. Swap them without touching screens.
- **Pure logic is separate.** Everything in `src/lib/` has no React imports and is unit tested with `node:test`.
- **Local-only collection in v1.** Accounts and sync are a later phase. Storage goes through `src/storage/kv.ts`, so a backend can replace it.

## Roadmap ideas

1. Accounts and cloud sync
2. Offline card recognition on the device
3. Portfolio value history chart (store a daily snapshot of the total)
4. Set completion tracking
5. Price alerts
6. Links to buy on TCGplayer
