import test from 'node:test';
import assert from 'node:assert/strict';
import { POST, OPTIONS } from '../api/identify.ts';

function req(body: unknown): Request {
  return new Request('http://localhost/api/identify', { method: 'POST', body: typeof body === 'string' ? body : JSON.stringify(body) });
}

test('identify: refuses to run without a server key', async () => {
  delete process.env.ANTHROPIC_API_KEY;
  const res = await POST(req({ image: 'abc' }));
  assert.equal(res.status, 500);
});

test('identify: validates input before calling the model', async () => {
  process.env.ANTHROPIC_API_KEY = 'test-key';
  const realFetch = globalThis.fetch;
  let called = false;
  globalThis.fetch = (async () => { called = true; return new Response('{}'); }) as typeof fetch;
  try {
    assert.equal((await POST(req('not json'))).status, 400);
    assert.equal((await POST(req({}))).status, 400);
    assert.equal((await POST(req({ image: 'x'.repeat(6_000_001) }))).status, 400);
    assert.equal((await POST(req({ image: 'abc', mediaType: 'image/gif' }))).status, 400);
    assert.equal(called, false);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('identify: sends the image to the model and returns clean JSON', async () => {
  process.env.ANTHROPIC_API_KEY = 'test-key';
  const realFetch = globalThis.fetch;
  let seen: { url: string; headers: Record<string, string>; body: any } | null = null;
  globalThis.fetch = (async (url: string, init: RequestInit) => {
    seen = { url, headers: init.headers as Record<string, string>, body: JSON.parse(String(init.body)) };
    return new Response(JSON.stringify({ content: [{ type: 'text', text: 'Sure! {"is_pokemon_card": true, "name": "Furret", "number": "136/189", "set": null}' }] }), { status: 200 });
  }) as typeof fetch;
  try {
    const res = await POST(req({ image: 'AAAA', mediaType: 'image/png' }));
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { is_pokemon_card: true, name: 'Furret', number: '136/189', set: null });
    assert.equal(seen!.url, 'https://api.anthropic.com/v1/messages');
    assert.equal(seen!.headers['x-api-key'], 'test-key');
    assert.equal(seen!.body.messages[0].content[0].source.media_type, 'image/png');
    assert.equal(seen!.body.messages[0].content[0].source.data, 'AAAA');
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('identify: reports upstream failure and unreadable output without leaking details', async () => {
  process.env.ANTHROPIC_API_KEY = 'test-key';
  const realFetch = globalThis.fetch;
  try {
    globalThis.fetch = (async () => new Response('boom', { status: 529 })) as typeof fetch;
    assert.equal((await POST(req({ image: 'AAAA' }))).status, 502);
    globalThis.fetch = (async () => new Response(JSON.stringify({ content: [{ type: 'text', text: 'no json here' }] }))) as typeof fetch;
    assert.equal((await POST(req({ image: 'AAAA' }))).status, 422);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('identify: answers CORS preflight', () => {
  const res = OPTIONS();
  assert.equal(res.status, 204);
  assert.ok(res.headers.get('Access-Control-Allow-Methods')?.includes('POST'));
});
