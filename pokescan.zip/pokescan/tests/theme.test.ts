import test from 'node:test';
import assert from 'node:assert/strict';
import { darkColors, lightColors } from '../src/theme/tokens.ts';

function rgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function luminance(hex: string): number {
  const [r, g, b] = rgb(hex).map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function contrast(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}
function hueAndSaturation(hex: string): { h: number; s: number } {
  const [r, g, b] = rgb(hex).map((v) => v / 255);
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  const l = (max + min) / 2;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  let h = 0;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s };
}

for (const [name, c] of [['light', lightColors], ['dark', darkColors]] as const) {
  test(`${name}: every color is a flat 6-digit hex (no gradients, no alpha tricks)`, () => {
    for (const [key, value] of Object.entries(c)) assert.match(value, /^#[0-9A-Fa-f]{6}$/, key);
  });

  test(`${name}: no purple or violet hues`, () => {
    for (const [key, value] of Object.entries(c)) {
      const { h, s } = hueAndSaturation(value);
      const purple = h >= 255 && h <= 325 && s > 0.12;
      assert.equal(purple, false, `${key} ${value} has hue ${h.toFixed(0)}`);
    }
  });

  test(`${name}: text contrast meets WCAG AA (4.5:1)`, () => {
    assert.ok(contrast(c.text, c.bg) >= 4.5, 'text on bg');
    assert.ok(contrast(c.text, c.surface) >= 4.5, 'text on surface');
    assert.ok(contrast(c.textMuted, c.bg) >= 4.5, 'muted on bg');
    assert.ok(contrast(c.textMuted, c.surface) >= 4.5, 'muted on surface');
    assert.ok(contrast(c.accentText, c.bg) >= 4.5, 'accent text on bg');
    assert.ok(contrast(c.onAccent, c.accent) >= 4.5, 'text on accent button');
    assert.ok(contrast(c.up, c.surface) >= 3, 'gain on surface');
    assert.ok(contrast(c.down, c.surface) >= 3, 'loss on surface');
  });
}

import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

function sourceFiles(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...sourceFiles(p));
    else if (/\.(ts|tsx)$/.test(name)) out.push(p);
  }
  return out;
}

test('source: no gradients anywhere in the app', () => {
  for (const file of [...sourceFiles('app'), ...sourceFiles('src')]) {
    const text = readFileSync(file, 'utf8');
    assert.doesNotMatch(text, /linear-?gradient|radial-?gradient|expo-linear-gradient/i, file);
  }
});

test('source: colors come from tokens (no hex literals outside tokens.ts)', () => {
  for (const file of [...sourceFiles('app'), ...sourceFiles('src')]) {
    if (file.endsWith('tokens.ts')) continue;
    const text = readFileSync(file, 'utf8');
    assert.doesNotMatch(text, /#[0-9A-Fa-f]{6}\b/, file);
  }
});
