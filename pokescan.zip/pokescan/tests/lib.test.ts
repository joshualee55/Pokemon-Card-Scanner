import test from 'node:test';
import assert from 'node:assert/strict';
import { parseCard, parseSummaries, cardImage } from '../src/lib/tcgdex.ts';
import { parseSearch, parseHistory, pickProduct, latestMarket } from '../src/lib/prices.ts';
import { filterRange, percentChange, toChartPath } from '../src/lib/history.ts';
import { addOrIncrement, setQuantity, totalValue, totalCards, sortByValue } from '../src/lib/collection.ts';
import { parseIdentify, rankCandidates } from '../src/lib/identify.ts';
import { formatUsd, formatPercent } from '../src/lib/format.ts';

test('tcgdex: parses summaries and skips junk rows', () => {
  const rows = parseSummaries([{ id: 'swsh3-136', localId: '136', name: 'Furret', image: 'https://x/y' }, { nope: 1 }, null]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].name, 'Furret');
  assert.equal(cardImage(rows[0].image, 'high'), 'https://x/y/high.webp');
  assert.equal(cardImage(undefined), undefined);
  assert.deepEqual(parseSummaries({ not: 'an array' }), []);
});

test('tcgdex: parses card detail with printed total', () => {
  const c = parseCard({ id: 'swsh3-136', localId: '136', name: 'Furret', set: { id: 'swsh3', name: 'Darkness Ablaze', cardCount: { official: 189, total: 201 } }, rarity: 'Common' });
  assert.equal(c?.setName, 'Darkness Ablaze');
  assert.equal(c?.officialTotal, 189);
  assert.equal(parseCard({}), null);
});

const products = parseSearch([
  { product_id: 1, name: 'Charizard ex - 199/165', set: 'SV: Scarlet & Violet 151', number: '199/165', market: '300.29' },
  { product_id: 2, name: 'Charizard ex - 054/165', set: 'SV: Scarlet & Violet 151', number: '054/165', market: '12.50' },
  { product_id: 3, name: 'Charizard - 199/165', set: 'Some Other Set', number: '199/165', market: '1.00' },
]);

test('prices: parses search rows and builds a fallback url', () => {
  assert.equal(products.length, 3);
  assert.equal(products[0].market, 300.29);
  assert.equal(products[0].url, 'https://tickermint.cards/card/1');
  assert.equal(parseSearch({ results: [{ product_id: 9, name: 'X' }] })[0].productId, '9');
});

test('prices: picks the right card and refuses to guess', () => {
  const hit = pickProduct(products, { name: 'Charizard ex', localId: '199', officialTotal: 165, setName: 'Scarlet & Violet 151' });
  assert.equal(hit?.productId, '1');
  // number matches but neither name nor set does -> no price rather than a wrong price
  assert.equal(pickProduct(products, { name: 'Pikachu', localId: '199', setName: 'Nowhere' }), null);
  // number that exists nowhere
  assert.equal(pickProduct(products, { name: 'Charizard ex', localId: '5' }), null);
});

test('prices: parses history keyed by printing, sorted oldest first', () => {
  const h = parseHistory({ Holofoil: [{ snapshot_date: '2026-11-02', low: '1.0', market: '2.50' }, { snapshot_date: '2026-11-01', low: '1.0', market: '2.00' }], Normal: [] });
  assert.deepEqual(Object.keys(h), ['Holofoil']);
  assert.equal(h.Holofoil[0].date, '2026-11-01');
  assert.equal(latestMarket(h, 'Holofoil'), 2.5);
  assert.equal(latestMarket(h, 'Missing printing'), 2.5);
  assert.equal(latestMarket({}), null);
  assert.deepEqual(parseHistory('garbage'), {});
});

test('history: range filter, percent change, chart path', () => {
  const pts = [
    { date: '2026-06-01', market: 10, low: 9 },
    { date: '2026-10-20', market: 20, low: 18 },
    { date: '2026-11-15', market: 30, low: 27 },
  ];
  const today = new Date('2026-11-17T00:00:00Z');
  assert.equal(filterRange(pts, '1M', today).length, 2);
  assert.equal(filterRange(pts, 'ALL', today).length, 3);
  assert.equal(percentChange(pts), 200);
  assert.equal(percentChange([pts[0]]), null);
  const g = toChartPath(pts, 100, 50, 0);
  assert.equal(g.min, 10);
  assert.equal(g.max, 30);
  assert.ok(g.d.startsWith('M0.0 50.0'));
  assert.ok(g.d.endsWith('L100.0 0.0'));
  assert.equal(toChartPath([], 100, 50).d, '');
});

test('collection: add, increment, set quantity, remove, totals', () => {
  const now = new Date('2026-11-17T00:00:00Z');
  let items = addOrIncrement([], { id: 'a', name: 'A', printing: 'Holofoil', lastPrice: 10 }, 1, now);
  items = addOrIncrement(items, { id: 'a', name: 'A', printing: 'Holofoil', lastPrice: 10 }, 2, now);
  items = addOrIncrement(items, { id: 'a', name: 'A', printing: 'Normal', lastPrice: 1 }, 1, now);
  items = addOrIncrement(items, { id: 'b', name: 'B' }, 1, now);
  assert.equal(items.length, 3);
  assert.equal(items[0].qty, 3);
  assert.equal(totalCards(items), 5);
  assert.deepEqual(totalValue(items), { value: 31, unpriced: 1 });
  assert.equal(sortByValue(items)[0].printing, 'Holofoil');
  items = setQuantity(items, 'a', 'Holofoil', 1);
  assert.equal(totalValue(items).value, 11);
  items = setQuantity(items, 'a', 'Holofoil', 0);
  assert.equal(items.length, 2);
});

test('identify: parses scan output and ranks by collector number', () => {
  assert.equal(parseIdentify({ is_pokemon_card: false, name: 'x' }), null);
  assert.equal(parseIdentify({ name: '  ' }), null);
  const hint = parseIdentify({ name: ' Furret ', number: '136/189', set: null });
  assert.deepEqual(hint, { name: 'Furret', number: '136/189', set: null });
  const ranked = rankCandidates(
    [{ id: 'x-1', localId: '001', name: 'Furret' }, { id: 'swsh3-136', localId: '136', name: 'Furret' }],
    hint!,
  );
  assert.equal(ranked[0].id, 'swsh3-136');
});

test('format: currency and percent', () => {
  assert.equal(formatUsd(1234.5), '$1,234.50');
  assert.equal(formatUsd(null), '\u2014');
  assert.equal(formatPercent(4.25), '+4.3%');
  assert.equal(formatPercent(-2), '-2.0%');
});
